//Game States
var PLAY=1;
var END=0;
var gameState=1;
var fruitG;
var knife, apple, orange, guava, fruits;
var knifeImage, appleImg, orangeImg, guavaImg ;


function preload(){
  
  knifeImage = loadImage("knife.png");
  appleImg = loadImage("apple.jpg");
   guavaImg = loadImage("29563501.jpg");
   appleImg = loadImage("orange.png");
}



function setup() {
  createCanvas(600, 600);
  
  //creating sword
   knife=createSprite(40,200,20,20);
   knife.addImage(knifeImage);
   knife.scale=0.7
  fruitG=new Group();
  
  //set collider for sword
  knife.setCollider("rectangle",0,0,40,40);

  score=0;
  //create fruit and monster Group variable here
}

function draw() {
  background("lightblue");
  
  if(gameState===PLAY){
    
    //calling fruit and monster function
    
    // Move knife with mouse
    knife.y=World.mouseY;
    knife.x=World.mouseX;
  
    // Increase score if knife touching fruit
   
    // Go to end state if knife touching enemy
      
  }
  spawnfruits();
  drawSprites();
  
  //Display score
  textSize(25);
  text("Score : "+ score,250,50);
}

function spawnfruits(){
  if(World.frameCount%60===0){
    fruits = createSprite(0,0,40,40)
    r=Math.round(random(1,3));
    if(r===1){
      fruits.addImage(appleImg);
      fruits.scale=0.03;
    }
    if(r===2){
      fruits.addImage(orangeImg);
      fruits.scale=0.3;
    }
    if(r===3){
       fruits.addImage(guavaImg);
      fruits.scale=1;
       }
    
    
  }
}



